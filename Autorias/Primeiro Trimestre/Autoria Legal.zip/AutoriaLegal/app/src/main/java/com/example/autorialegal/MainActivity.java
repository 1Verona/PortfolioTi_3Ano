package com.example.autorialegal;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();


        Button button = findViewById(R.id.LoginB);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String login = ((EditText) findViewById(R.id.editTextTextPersonName)).getText().toString();
                String senha = ((EditText) findViewById(R.id.Senha)).getText().toString();

                if (login.equals("jacksonfoda") && senha.equals("java123")) {
                    Toast.makeText(MainActivity.this, "Bem vindo", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, Tela_Legal.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Verifique as Credenciais", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}